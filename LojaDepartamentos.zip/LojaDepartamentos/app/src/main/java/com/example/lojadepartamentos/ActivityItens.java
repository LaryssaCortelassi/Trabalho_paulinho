package com.example.lojadepartamentos;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class ActivityItens extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_itens);
    }
}